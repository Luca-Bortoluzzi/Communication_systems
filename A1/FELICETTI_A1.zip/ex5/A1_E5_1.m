clc;
clear;
close all;
n=63;
k=57;
r=n-k;
%% 1
c = dec2bin(1:2^r-1,r)' - '0'; %matrix 6x63
w = sum(c,1); % weight=1;
P_T= c(:, w >= 2); %6x57
H = [P_T, eye(r)]; % parity check matrix
P=P_T';
G = [eye(k), P]; %Generator Matrix
%% 2
p_an = logspace(-3,-1,100);
pW_an = 1 -(1-p_an).^n -n.*p_an.*(1-p_an).^(n-1); %Analytical Formula

%% 3
fig_q2 = figure('Color', 'w', 'Position', [100, 100, 760, 400]);
loglog(p_an, pW_an, '-', 'Color', [30, 136, 229]/255, 'LineWidth', 2.2);
grid on; box off;
xlim([1e-3, 1e-1]);
xlabel('Bit Error Probability p', 'FontSize', 11);
ylabel('Codeword Error Probability P_W(p)', 'FontSize', 11);
title('Analytical Codeword Error Probability - Hamming (63, 57)', 'FontSize', 12);
exportgraphics(fig_q2, 'E5_1_Q3.png', 'Resolution', 300);


%% 4
p_sim = logspace(-3, -1, 8);
pW_sim = zeros(size(p_sim));
target_errors = 100;

twos = 2.^(r-1:-1:0); % Powers of 2
H_dec = twos * H;     % Valore decimale di ciascuna colonna di H (1 x 63)

for i = 1:length(p_sim)
    p = p_sim(i);
    current_errors = 0;
    totalWords = 0;

    while current_errors < target_errors
        % 1. Generazione messaggio e codeword
        messageBits = randi([0 1], 1, k);
        codeword = mod(messageBits * G, 2);

        % 2. Canale BSC: parola ricevuta
        receivedWord = mod(codeword + (rand(1, n) < p), 2);

        % 3. Calcolo sindrome in GF(2) e conversione in decimale
        syndrome_vec = mod(receivedWord * H', 2);
        syndrome = syndrome_vec * twos';

        % 4. Correzione cercando la colonna corrispondente in H_dec
        decodedWord = receivedWord;
        if syndrome > 0
            err_pos = find(H_dec == syndrome, 1);
            decodedWord(err_pos) = mod(decodedWord(err_pos) + 1, 2);
        end

        current_errors = current_errors + any(decodedWord ~= codeword);
        totalWords = totalWords + 1;
    end

    pW_sim(i) = current_errors / totalWords;
end
%% 5
fig_q3 = figure('Color', 'w', 'Position', [100, 100, 760, 400]);
loglog(p_sim, pW_sim, 'o-', 'Color', [251, 140, 0]/255, 'LineWidth', 2.0, 'MarkerSize', 6, 'MarkerFaceColor', [251, 140, 0]/255);
grid on; box off;
xlim([1e-3, 1e-1]);
xlabel('Bit Error Probability p', 'FontSize', 11);
<<<<<<< HEAD:A1/ex5/A1_E5_1.m
ylabel('$Estimated Codeword Error Probability \hat{P}_W(p)$','Interpreter','Latex', 'FontSize', 11);
=======
ylabel('$Estimated\ Codeword\ Error\ Probability\ \hat{P}_W(p)$', 'FontSize', 11,'Interpreter','latex');
>>>>>>> b0d366bc9c1cf1de679e9cbbb49e15c3e99d1183:A1/ex5/ex5a.m
title('Monte Carlo Simulation - Hamming (63, 57) (100 target errors)', 'FontSize', 12);
exportgraphics(fig_q3, 'E5_1_Q5.png', 'Resolution', 300);

%% 6
fig_q5 = figure('Color', 'w', 'Position', [100, 100, 760, 400]);
loglog(p_an, pW_an, '-', 'Color', [30, 136, 229]/255, 'LineWidth', 2.2, ...
    'DisplayName', 'Analytical P_W(p)');
hold on;
loglog(p_sim, pW_sim, 'o--', 'Color', [251, 140, 0]/255, 'LineWidth', 2.0, ...
    'MarkerSize', 6, 'MarkerFaceColor', [251, 140, 0]/255, ...
    'DisplayName', 'Simulated P_W(p)');

grid on; box off;
xlim([1e-3, 1e-1]);
xlabel('Bit Error Probability p', 'FontSize', 11);
ylabel('Codeword Error Probability P_W(p)', 'FontSize', 11);
title('Bounded-Distance vs. Complete Minimum-Distance Decoder - Hamming (63, 57)', 'FontSize', 11);
legend('Location', 'northwest', 'FontSize', 9.5);
exportgraphics(fig_q5, 'E5_1_Q6.png', 'Resolution', 300);
% The simulated curve closely follows the analytical one showing how
% accurate the bounded-distance decoder is.

%% 7
%The C(63,57) binary Hamming code is a perfect code: the 2^57 is joint Hamming spheres of radius t = 1 
%each containing 2^6 vectors completely partition the entire ambient space
%Because every possible syndrome maps uniquely to an error pattern of weight <=1 and no
%received vector falls outside the decoding spheres, no decoding failures can ever occur
%Consequently, the bounded-distance decoder and the complete minimum-distance decoder
%are identical and yield the exact same codeword error probability over a BSC
