
clc; 
clear; 

% -------------------------------------------------------------------------
% 3.1
% -------------------------------------------------------------------------
I = eye(5); % 5x5 Identity matrix (for systematic message bits)

% Define parity check sub-matrix A (5x5)
A = [1 1 1 0 0;
    0 1 1 1 0;
    0 0 1 1 1;
    1 0 0 1 1;
    1 1 0 0 1];

% Systematic Generator Matrix G1 = [I_5 | A] of size (5x10)
G1 = [I A];

P = A;      % Assign parity block P = A
I = eye(5); % Re-declare 5x5 Identity matrix for parity bits

% Transposed Parity-Check Matrix H^T = [P; I_5] of size (10x5)
% Satisfies the orthogonality condition: G1 * H^T = 0 (mod 2)
HT = [P; I];

% -------------------------------------------------------------------------
% 3.2
% -------------------------------------------------------------------------
m = [1 0 0 1 0]; % 5-bit binary input message vector (1x5)

% Encoding: generate valid codeword y1 = m * G1 (1x10)
y1 = mod(m*G1,2) 

% Single-bit error vector with an error at position 1 (1x10)
e = [1 0 0 0 0 0 0 0 0 0];

% Corrupted received vector y2 = (y1 + e) mod 2
y2 = mod(y1+e, 2);

% -------------------------------------------------------------------------
% 3.3
% -------------------------------------------------------------------------
HT_1 = HT;

% Perform an elementary column operation over GF(2):
% Column 1 = Column 1 XOR Column 2.
% This represents multiplying H^T by an invertible matrix M in GL(5, GF(2)).
% It leaves the kernel unchanged: Ker(H1) = Ker(H) = Code C.
HT_1(:, 1) = mod(HT(:, 1) + HT(:, 2), 2)

s1 = mod(y1*HT_1, 2) %null sindrome
s2 = mod(y2*HT_1, 2) %NON null sindrome


% -------------------------------------------------------------------------
% 3.4
% -------------------------------------------------------------------------
% Extend H^T to size (10x7) by appending two redundant columns
% (specifically, duplicating Column 1 and Column 2 of HT).
% The column rank remains 5, so Ker(H2) = Ker(H).
HT_2 = [HT, HT(:, 1), HT(:, 2)]

% Calculate 7-bit syndrome for valid codeword y1:
% s1 = y1 * H2^T mod 2 -> Expects [0 0 0 0 0 0 0] (Zero Syndrome)
s1 = mod(y1*HT_2, 2)

% Calculate 7-bit syndrome for corrupted vector y2:
% s2 = y2 * H2^T mod 2 -> Expects Non-Zero Syndrome (Row 1 of H2^T)
s2 = mod(y2*HT_2, 2)