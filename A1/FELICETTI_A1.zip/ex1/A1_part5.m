%reinserted previous parts to make the code work       
clc;
clear;
close all;
I = eye(5);
A = [1 1 1 0 0;
    0 1 1 1 0;
    0 0 1 1 1;
    1 0 0 1 1;
    1 1 0 0 1;];
B = [1 1 0 0 0;
    0 1 1 1 0;
    0 0 1 1 1;
    1 0 0 1 1;
    1 1 0 0 1;];
G1 = [I A];
G2 = [I B];
k = 5;
%% 1.1
v = dec2bin(0:2^k-1) - '0';
%% 1.2
n = 10;                    % codeword lenght (10)
c1 = mod(v*G1, 2);
c2 = mod(v*G2, 2);
%% 1.3 and 1.4
%variable define
hw1=zeros(32, 1);
hw2=zeros(32, 1);
mult1=zeros(11,1);
mult2=zeros(11,1);
for i=1:32
    %hamming weight
    hw1(i, 1) = sum(c1(i, : ));
    hw2(i, 1) = sum(c2(i, :));
    %Multiplicities
    a1 = hw1(i, 1); %%temp variables
    a2 = hw2(i, 1);         %ATTENTION hw2!!! not hw1!!!
    mult1(a1+1, 1) = mult1(a1+1, 1) + 1;
    mult2(a2+1, 1) = mult2(a2+1, 1) + 1;
end
%% 1.5
% we don't calculate the hamming distance of vector row 32 because it's
% redundant since it is calculated by all the precedent vectors so on the
% 32x32 matrix hd it would all be zeroes
min1 = zeros(31,1);
min2 = zeros(31,1);
hd1 = zeros(32, 32);
hd2 = zeros(32, 32);
for i=1:31
    for j= i+1:32
        hd1(i,j) = sum(xor(c1(i,1:10), c1(j,1:10))) ;
        hd2(i,j) = sum(xor(c2(i,1:10), c2(j,1:10))) ;

    end
    min1(i,:) = min(setdiff(unique(hd1(i,:)), 0));
    min2(i,:) = min(setdiff(unique(hd2(i,:)), 0));
end

%% Part 2

%% 2.1 
% Evaluate PUE(p) for both codes using their weight spectra.
p_bsc = 0.5;     % Bernoulli probability for BSC

PUE1_bsc = 0;
PUE2_bsc = 0;

for w = 1:n
    PUE1_bsc = PUE1_bsc + mult1(w+1) * p_bsc^w * (1-p_bsc)^(n-w);
    PUE2_bsc = PUE2_bsc + mult2(w+1) * p_bsc^w * (1-p_bsc)^(n-w);
end

%% 2.2 
% Plot both curves on the same log–log axes for p ∈[10−6,10−1].
num = 1000;   %number of values for probability interval
p_interval = logspace(-6, -1, num);   %make a spaced vector from 10^-6 to 10^-1

PUE1_log = zeros(size(p_interval));
PUE2_log = zeros(size(p_interval));

% REMEMBER THAT n = 10 (codeword lenght)
for idx= 1:num
    p = p_interval(idx);
    for w = 1:n
    PUE1_log(idx) = PUE1_log(idx) + mult1(w+1) * p^w * (1-p)^(n-w);
    PUE2_log(idx) = PUE2_log(idx) + mult2(w+1) * p^w * (1-p)^(n-w);
    end
end




%% part 4

p = [0.10, 0.09, 0.08, 0.07, 0.06];     % given prob for part 4
k = 5;   % information length != codeword length = (info length + redundancy bits)
n = 10; % codeword length

% 4.1 (in the for cycle)


% BSC modeling: y = c_rand + e | where y is the codeword received and "e" are errors during the transmission

P = G1(:, k+1:end);     %parity submatrix (from 6 to 10 columns [5x5])
H = [P', eye(n-k)];    % Syndrome matrix

target_errors = 10;     % stop the cycle at undetected error = 10;
% we need to stop the cycle at 10 undetected errors and then at 100
for j=1:2
    for i=1:length(p)
    
        undetected_errors = 0;  % self-explanatory
        total_transmitted = 0;  % //
        
        while undetected_errors < target_errors
            % 4.1
            u = randi([0, 1], 1, k);     % random generation of a [1 x k] only for 0 and 1
            c_rand = mod(u * G1, 2);    % random gen of a vector 1 x 10 (codeword length)
            
            e = rand(1, length(c_rand)) < p(i);  % generate random noise in BSC with less probability than current
            y = mod(c_rand + e, 2);              % received message
    
            % 4.2 Syndrome calculus
            s = mod(y * H', 2);
    
            % 4.3 Error detection
            if all(s == 0) && ~isequal(y, c_rand)
                undetected_errors = undetected_errors + 1;  % undetected increment
            end
    
            total_transmitted = total_transmitted + 1;  % transmitted anyway
    
        end

    target_errors = 100;    % change the target to 100 errors
    end
end


%% PART 5

% Define the BSC crossover probability p in the range
% 10^-2 <= p <= 10^-1 using 200 logarithmically spaced points
p = logspace(-2, -1, 200);

% Probability of correct reception in one transmission attempt:
% all n bits must be received without error
% p0 = P(COR, i = 1)
p0 = (1 - p).^n;

% Initialize the probability of undetected error
% as a vector with the same length as p
p1 = zeros(1, length(p));

% Compute the undetected error probability:
% P_UE(p) = sum_{w=1}^n A_w * p^w * (1-p)^(n-w)
% where mult1(w+1) corresponds to A_w,
% i.e. the number of codewords of Hamming weight w
for w = 1:n
    p1 = p1 + mult1(w+1) * p.^w .* (1-p).^(n-w);
end

% Probability that the received block is rejected
% The three possible events are COR, Ue and REJ, therefore:
% p0 + p1 + p2 = 1
p2 = 1 - p0 - p1;

% Maximum number of ARQ transmission attempts considered
i = 3;

% Compute P(COR,k) for k = 1, 2, 3
if i > 1

    % Initialize a matrix where each row contains
    % P(COR,k) for all values of p
    p0_i = zeros(i, length(p2));

    % For the block to be correctly received at attempt k,
    % the previous k-1 attempts must have been rejected
    % and the k-th attempt must be correct:
    % P(COR,k) = p2^(k-1) * p0
    for k=1:i
        p0_i(k,:) = (p2.^(k-1)).*p0;
    end
end

% Compute the quantities required by the exercise:
% 1 - P(COR,i), for i = 1, 2, 3
y1 = 1 - p0_i(1,:);
y2 = 1 - p0_i(2,:);
y3 = 1 - p0_i(3,:);

% Colori coordinati con la presentazione Beamer
plot_blue   = [30, 136, 229] / 255;
plot_orange = [251, 140, 0] / 255;
plot_red    = [229, 57, 53] / 255;

fig_p5 = figure('Color', 'w', 'Position', [100, 100, 760, 400]);

semilogx(p, y1, '-', 'Color', plot_blue, 'LineWidth', 2.2);
hold on;
semilogx(p, y2, '-', 'Color', plot_orange, 'LineWidth', 2.2);
semilogx(p, y3, '-', 'Color', plot_red, 'LineWidth', 2.2);

grid on; box off;
xlim([1e-2, 1e-1]);
ylim([0, 1.03]);
xlabel('BSC crossover probability p', 'FontSize', 11);
ylabel('1 - P(COR, i)', 'FontSize', 11);
title('ARQ: 1 - P(COR, i) vs. Channel Error Probability', 'FontSize', 12, 'FontWeight', 'bold');
legend('i = 1', 'i = 2', 'i = 3', 'Location', 'southeast', 'FontSize', 10);

exportgraphics(fig_p5, 'E1_P5_Q3.png', 'Resolution', 300);