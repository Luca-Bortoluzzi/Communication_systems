        
clc;
clear;
close all;
I = eye(5);
A = [1 1 1 0 0;
    0 1 1 1 0;
    0 0 1 1 1;
    1 0 0 1 1;
    1 1 0 0 1;];
B = [1 1 0 0 0;
    0 1 1 1 0;
    0 0 1 1 1;
    1 0 0 1 1;
    1 1 0 0 1;];
G1 = [I A];
G2 = [I B];
k = 5;
%% 1.1
v = dec2bin(0:2^k-1) - '0';
%% 1.2
n = 10;                    % codeword lenght (10)
c1 = mod(v*G1, 2);
c2 = mod(v*G2, 2);
%% 1.3 and 1.4
%variable define
hw1=zeros(32, 1);
hw2=zeros(32, 1);
mult1=zeros(11,1);
mult2=zeros(11,1);
for i=1:32
    %hamming weight
    hw1(i, 1) = sum(c1(i, : ));
    hw2(i, 1) = sum(c2(i, :));
    %Multiplicities
    a1 = hw1(i, 1); %%temp variables
    a2 = hw2(i, 1);         %ATTENTION hw2!!! not hw1!!!
    mult1(a1+1, 1) = mult1(a1+1, 1) + 1;
    mult2(a2+1, 1) = mult2(a2+1, 1) + 1;
end
%% 1.5
% we don't calculate the hamming distance of vector row 32 because it's
% redundant since it is calculated by all the precedent vectors so on the
% 32x32 matrix hd it would all be zeroes
min1 = zeros(31,1);
min2 = zeros(31,1);
hd1 = zeros(32, 32);
hd2 = zeros(32, 32);
for i=1:31
    for j= i+1:32
        hd1(i,j) = sum(xor(c1(i,1:10), c1(j,1:10))) ;
        hd2(i,j) = sum(xor(c2(i,1:10), c2(j,1:10))) ;

    end
    min1(i,:) = min(setdiff(unique(hd1(i,:)), 0));
    min2(i,:) = min(setdiff(unique(hd2(i,:)), 0));
end

%% Part 2

%% 2.1 
% Evaluate PUE(p) for both codes using their weight spectra.
p_bsc = 0.5;     % Bernoulli probability for BSC

PUE1_bsc = 0;
PUE2_bsc = 0;

for w = 1:n
    PUE1_bsc = PUE1_bsc + mult1(w+1) * p_bsc^w * (1-p_bsc)^(n-w);
    PUE2_bsc = PUE2_bsc + mult2(w+1) * p_bsc^w * (1-p_bsc)^(n-w);
end

%% 2.2 
% Plot both curves on the same log–log axes for p ∈[10−6,10−1].
num = 1000;   %number of values for probability interval
p_interval = logspace(-6, -1, num);   %make a spaced vector from 10^-6 to 10^-1

PUE1_log = zeros(size(p_interval));
PUE2_log = zeros(size(p_interval));

% REMEMBER THAT n = 10 (codeword lenght)
for idx= 1:num
    p = p_interval(idx);
    for w = 1:n
    PUE1_log(idx) = PUE1_log(idx) + mult1(w+1) * p^w * (1-p)^(n-w);
    PUE2_log(idx) = PUE2_log(idx) + mult2(w+1) * p^w * (1-p)^(n-w);
    end
end

% Colori coordinati con la presentazione Beamer
navy = [18, 43, 73] / 255;
red_plot = [229, 57, 53] / 255;

fig_p2 = figure('Color', 'w', 'Position', [100, 100, 720, 380]);
loglog(p_interval, PUE1_log, '-', 'Color', navy, 'LineWidth', 2.2);
hold on;
loglog(p_interval, PUE2_log, '--', 'Color', red_plot, 'LineWidth', 2.2);
grid on; box off;
xlabel('BSC crossover probability p', 'FontSize', 11);
ylabel('P_{UE}(p)', 'FontSize', 11);
title('Undetected-error probability on BSC', 'FontSize', 12, 'FontWeight', 'bold');
legend('Code 1 (G_1, d_{min} = 4)', 'Code 2 (G_2, d_{min} = 3)', 'Location', 'southeast', 'FontSize', 10);
xlim([1e-6, 1e-1]);
ylim([1e-24, 1e0]);

exportgraphics(fig_p2, 'E1_P2_Q2.png', 'Resolution', 300);

%% 2.3
% For small p, find the leading term of the two PUE expressions and explain its relationship with d_min and A_min.

%R: For small probabilities, the '(1-p)' part of the sum, can be discarded and the new
%formula contains only the multiplicity part multiplied by probability.
% For linear codes, the dmin between c1 and c2 is equivalent to the result
% of the XOR between the two codewords that is the hamming weight.


%% 2.4
% Compare the two codes: which one has better error-detection performance, and why?

%R: As you can see in the figure the code1 rather than the code2 has a less
%ripid curve that means better performance, for a logarithmic graph the dmin
%leads the gradient because log(Amin) is a constant.
% log Pue(p) = log(Amin) + dmin*log(p)
% for small p (p->0) the formula can be approximate to P_UE ~=
% A_dmin*p^dimn so:
% for G1 the first not null term is for i =4 --> A_min = 15 --> the main
% term P_UE ~= 15p^4
% for G2 the first not null term is for i =3 --> A_min = 1 --> the main
% term P_UE ~= 2p^3


